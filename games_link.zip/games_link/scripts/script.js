import { db, auth } from "./firebase.js";
import { collection, addDoc, onSnapshot, query, orderBy } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";

const commentsRef = collection(db, "comments");

document.addEventListener("DOMContentLoaded", () => {
  const commentForm = document.getElementById("commentForm");
  const commentList = document.getElementById("commentList");
  const userInfo = document.getElementById("userInfo");
  const loginPrompt = document.getElementById("loginPrompt");

  onAuthStateChanged(auth, (user) => {
    if (user) {
      loginPrompt.style.display = "none";
      userInfo.innerHTML = `مرحبا ${user.email} <button id="logoutBtn">خروج</button>`;
      commentForm.style.display = "flex";
      document.getElementById("logoutBtn").onclick = () => signOut(auth);
    } else {
      loginPrompt.style.display = "block";
      commentForm.style.display = "none";
      userInfo.innerHTML = "";
    }
  });

  commentForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const user = auth.currentUser;
    if (!user) {
      alert("سجل دخول باش تقدر تكتب تعليق");
      return;
    }
    await addDoc(commentsRef, {
      name: user.email,
      message: document.getElementById("message").value,
      time: Date.now()
    });
    e.target.reset();
  });

  const q = query(commentsRef, orderBy("time", "desc"));
  onSnapshot(q, (snapshot) => {
    commentList.innerHTML = "";
    snapshot.forEach(doc => {
      const c = doc.data();
      commentList.innerHTML += `
        <div class="comment">
          <strong>${c.name}</strong>
          <p>${c.message}</p>
        </div>
      `;
    });
  });
});