import { initializeApp } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-analytics.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAkSrUcNhhcUPv9LPiQqJlIcIsP39s08DI",
  authDomain: "my-project-site-b55e2.firebaseapp.com",
  projectId: "my-project-site-b55e2",
  storageBucket: "my-project-site-b55e2.firebasestorage.app",
  messagingSenderId: "713485932266",
  appId: "1:713485932266:web:a1f9dbee0358db22782993",
  measurementId: "G-0W98VZN81F"
};

export const app = initializeApp(firebaseConfig);
export const analytics = getAnalytics(app);
export const auth = getAuth(app);
export const db = getFirestore(app);